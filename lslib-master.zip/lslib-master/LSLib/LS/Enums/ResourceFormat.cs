﻿namespace LSLib.LS.Enums;

public enum ResourceFormat
{
    LSX,
    LSB,
    LSF,
    LSJ
};
﻿/// <summary>
/// Cinematic arena flags.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum CinematicArenaFlag
    {
        None,
        Ignore,
        AlwaysShow
    }
}
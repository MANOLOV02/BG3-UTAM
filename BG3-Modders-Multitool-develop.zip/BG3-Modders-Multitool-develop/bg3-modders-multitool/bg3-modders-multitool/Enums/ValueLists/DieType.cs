﻿/// <summary>
/// The DieType
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum DieType
    {
        None,
        d4,
        d6,
        d8,
        d10,
        d12,
        d20,
        d100
    }
}
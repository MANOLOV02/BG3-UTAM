﻿/// <summary>
/// The Action Type
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum ActionType
    {
        Regular,
        Bonus
    }
}
﻿/// <summary>
/// The AlchemyCombinationType
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum AlchemyCombinationType
    {
        None,
        IngredientsToExtract,
        ExtractToSolution
    }
}
﻿/// <summary>
/// The IngredientCombineType
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum IngredientCombineType
    {
        None,
        Base,
        Additive
    }
}
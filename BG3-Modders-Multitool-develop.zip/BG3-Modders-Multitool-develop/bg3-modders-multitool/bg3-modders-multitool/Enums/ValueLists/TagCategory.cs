﻿/// <summary>
/// The TagCategory
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum TagCategory
    {
        None,
        Code,
        Dialog,
        Gender,
        Origin,
        Profession,
        Race,
        Story,
        Voice
    }
}
﻿/// <summary>
/// The Tension
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum Tension
    {
        any,
        low,
        high
    }
}
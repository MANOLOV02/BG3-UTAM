﻿/// <summary>
/// The ThrowOrigin
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum ThrowOrigin
    {
        Caster,
        Target
    }
}
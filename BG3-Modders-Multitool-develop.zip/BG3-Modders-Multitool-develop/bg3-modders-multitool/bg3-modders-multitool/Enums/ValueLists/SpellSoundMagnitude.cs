﻿/// <summary>
/// The spell sound magnitude.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum SpellSoundMagnitude
    {
        None,
        Small,
        Normal,
        Big
    }
}
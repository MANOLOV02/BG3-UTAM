﻿/// <summary>
/// The projectile types.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum ProjectileType
    {
        None,
        Arrow,
        Grenade
    }
}
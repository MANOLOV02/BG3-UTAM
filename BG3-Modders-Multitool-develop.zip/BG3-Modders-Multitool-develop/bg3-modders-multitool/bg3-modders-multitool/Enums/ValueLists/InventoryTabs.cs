﻿/// <summary>
/// The inventory tabs.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum InventoryTabs
    {
        Auto,
        Equipment,
        Consumable,
        Magical,
        Ingredient,
        Keys,
        Misc,
        Hidden,
        BooksAndKeys
    }
}
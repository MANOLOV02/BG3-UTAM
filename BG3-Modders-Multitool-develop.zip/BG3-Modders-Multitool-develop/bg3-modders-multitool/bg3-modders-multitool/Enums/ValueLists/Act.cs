﻿/// <summary>
/// The Act
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    using System.Runtime.Serialization;

    [DataContract]
    public enum Act
    {
        [EnumMember(Value = "1")]
        Act1
    }
}
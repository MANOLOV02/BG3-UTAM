﻿/// <summary>
/// The atmoshere types.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum AtmosphereType
    {
        None,
        Rain,
        Storm
    }
}
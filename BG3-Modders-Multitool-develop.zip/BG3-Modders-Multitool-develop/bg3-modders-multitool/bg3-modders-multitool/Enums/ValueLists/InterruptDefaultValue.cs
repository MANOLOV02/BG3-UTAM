﻿/// <summary>
/// The interupt default value.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum InterruptDefaultValue
    {
        None,
        Ask,
        Enabled
    }
}
﻿/// <summary>
/// The FlagType
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum FlagType
    {
        Invalid,
        Local,
        User,
        Party,
        Character,
        Global,
        Dialog
    }
}
﻿/// <summary>
/// The progression types.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum ProgressionType
    {
        Level,
        ChallengeRating
    }
}
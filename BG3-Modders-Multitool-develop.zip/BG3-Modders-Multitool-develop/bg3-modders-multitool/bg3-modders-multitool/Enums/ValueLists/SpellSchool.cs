﻿/// <summary>
/// The spell schools.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum SpellSchool
    {
        None,
        Abjuration,
        Conjuration,
        Divination,
        Enchantment,
        Evocation,
        Illusion,
        Necromancy,
        Transmutation
    }
}
﻿/// <summary>
/// The status sheathing.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum StatusSheathing
    {
        None,
        Instrument,
        Melee,
        Ranged,
        Sheathed
    }
}
﻿/// <summary>
/// The Custom Properties
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum CustomProperties
    {
        None,
        AlwaysBackstab,
        Unbreakable,
        CanBackstab,
        AlwaysHighGround
    }
}
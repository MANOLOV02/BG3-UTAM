﻿/// <summary>
/// The interupt context scope.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum InterruptContextScope
    {
        None,
        Self,
        Nearby
    }
}
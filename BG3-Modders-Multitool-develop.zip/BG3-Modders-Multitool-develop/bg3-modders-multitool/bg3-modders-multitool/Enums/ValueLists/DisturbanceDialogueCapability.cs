﻿/// <summary>
/// The DisturbanceDialogueCapability
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum DisturbanceDialogueCapability
    {
        Excl_CanTalk,
        Incl_Summon,
        Incl_Wildshape,
        Incl_OtherCannotTalk
    }
}
﻿/// <summary>
/// The spell sheathing.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum SpellSheathing
    {
        Somatic,
        DontChange,
        Instrument,
        Melee,
        Ranged,
        Sheathed,
        WeaponSet
    }
}
﻿/// <summary>
/// The line of sight flags.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum LineOfSightFlags
    {
        None,
        AddSourceHeight
    }
}
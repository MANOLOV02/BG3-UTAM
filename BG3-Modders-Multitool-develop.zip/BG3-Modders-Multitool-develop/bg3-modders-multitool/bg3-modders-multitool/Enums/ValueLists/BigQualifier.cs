﻿/// <summary>
/// The BigQualifier
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    using System.Runtime.Serialization;

    public enum BigQualifier
    {
        [EnumMember(Value = "None")]
        None,

        [EnumMember(Value = "1")]
        P1,

        [EnumMember(Value = "2")]
        P2,

        [EnumMember(Value = "3")]
        P3,

        [EnumMember(Value = "4")]
        P4,

        [EnumMember(Value = "5")]
        P5,

        [EnumMember(Value = "6")]
        P6,

        [EnumMember(Value = "7")]
        P7,

        [EnumMember(Value = "8")]
        P8,

        [EnumMember(Value = "9")]
        P9,

        [EnumMember(Value = "10")]
        P10,

        [EnumMember(Value = "11")]
        P11,

        [EnumMember(Value = "12")]
        P12,

        [EnumMember(Value = "13")]
        P13,

        [EnumMember(Value = "14")]
        P14,

        [EnumMember(Value = "15")]
        P15,

        [EnumMember(Value = "16")]
        P16,

        [EnumMember(Value = "17")]
        P17,

        [EnumMember(Value = "18")]
        P18,

        [EnumMember(Value = "19")]
        P19,

        [EnumMember(Value = "20")]
        P20,

        [EnumMember(Value = "21")]
        P21,

        [EnumMember(Value = "22")]
        P22,

        [EnumMember(Value = "23")]
        P23,

        [EnumMember(Value = "24")]
        P24,

        [EnumMember(Value = "25")]
        P25,

        [EnumMember(Value = "26")]
        P26,

        [EnumMember(Value = "27")]
        P27,

        [EnumMember(Value = "28")]
        P28,

        [EnumMember(Value = "29")]
        P29,

        [EnumMember(Value = "30")]
        P30,

        [EnumMember(Value = "31")]
        P31,

        [EnumMember(Value = "32")]
        P32,

        [EnumMember(Value = "33")]
        P33,

        [EnumMember(Value = "34")]
        P34,

        [EnumMember(Value = "35")]
        P35,

        [EnumMember(Value = "36")]
        P36,

        [EnumMember(Value = "37")]
        P37,

        [EnumMember(Value = "38")]
        P38,

        [EnumMember(Value = "39")]
        P39,

        [EnumMember(Value = "40")]
        P40,

        [EnumMember(Value = "41")]
        P41,

        [EnumMember(Value = "42")]
        P42,

        [EnumMember(Value = "43")]
        P43,

        [EnumMember(Value = "44")]
        P44,

        [EnumMember(Value = "45")]
        P45,

        [EnumMember(Value = "46")]
        P46,

        [EnumMember(Value = "47")]
        P47,

        [EnumMember(Value = "48")]
        P48,

        [EnumMember(Value = "49")]
        P49,

        [EnumMember(Value = "50")]
        P50,

        [EnumMember(Value = "51")]
        P51,

        [EnumMember(Value = "52")]
        P52,

        [EnumMember(Value = "53")]
        P53,

        [EnumMember(Value = "54")]
        P54,

        [EnumMember(Value = "55")]
        P55,

        [EnumMember(Value = "56")]
        P56,

        [EnumMember(Value = "57")]
        P57,

        [EnumMember(Value = "58")]
        P58,

        [EnumMember(Value = "59")]
        P59,

        [EnumMember(Value = "60")]
        P60,

        [EnumMember(Value = "61")]
        P61,

        [EnumMember(Value = "62")]
        P62,

        [EnumMember(Value = "63")]
        P63,

        [EnumMember(Value = "64")]
        P64,

        [EnumMember(Value = "65")]
        P65,

        [EnumMember(Value = "66")]
        P66,

        [EnumMember(Value = "67")]
        P67,

        [EnumMember(Value = "68")]
        P68,

        [EnumMember(Value = "69")]
        P69,

        [EnumMember(Value = "70")]
        P70,

        [EnumMember(Value = "71")]
        P71,

        [EnumMember(Value = "72")]
        P72,

        [EnumMember(Value = "73")]
        P73,

        [EnumMember(Value = "74")]
        P74,

        [EnumMember(Value = "75")]
        P75,

        [EnumMember(Value = "76")]
        P76,

        [EnumMember(Value = "77")]
        P77,

        [EnumMember(Value = "78")]
        P78,

        [EnumMember(Value = "79")]
        P79,

        [EnumMember(Value = "80")]
        P80,

        [EnumMember(Value = "81")]
        P81,

        [EnumMember(Value = "82")]
        P82,

        [EnumMember(Value = "83")]
        P83,

        [EnumMember(Value = "84")]
        P84,

        [EnumMember(Value = "85")]
        P85,

        [EnumMember(Value = "86")]
        P86,

        [EnumMember(Value = "87")]
        P87,

        [EnumMember(Value = "88")]
        P88,

        [EnumMember(Value = "89")]
        P89,

        [EnumMember(Value = "90")]
        P90,

        [EnumMember(Value = "91")]
        P91,

        [EnumMember(Value = "92")]
        P92,

        [EnumMember(Value = "93")]
        P93,

        [EnumMember(Value = "94")]
        P94,

        [EnumMember(Value = "95")]
        P95,

        [EnumMember(Value = "96")]
        P96,

        [EnumMember(Value = "97")]
        P97,

        [EnumMember(Value = "98")]
        P98,

        [EnumMember(Value = "99")]
        P99,

        [EnumMember(Value = "100")]
        P100
    }
}
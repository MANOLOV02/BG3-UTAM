﻿/// <summary>
/// The status heal types.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum StatusHealType
    {
        None,
        Vitality,
        PhysicalArmor,
        MagicArmor,
        AllArmor,
        All,
        Source
    }
}
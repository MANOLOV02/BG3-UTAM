﻿/// <summary>
/// The abilities.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum Ability
    {
        None,
        Strength,
        Dexterity,
        Constitution,
        Intelligence,
        Wisdom,
        Charisma
    }
}
﻿/// <summary>
/// The spell animation intent types.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum SpellAnimationIntentType
    {
        None,
        Aggressive,
        Peaceful,
        Action
    }
}
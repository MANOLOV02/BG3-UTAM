﻿/// <summary>
/// The weapon set.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum WeaponSet
    {
        Melee,
        Ranged
    }
}
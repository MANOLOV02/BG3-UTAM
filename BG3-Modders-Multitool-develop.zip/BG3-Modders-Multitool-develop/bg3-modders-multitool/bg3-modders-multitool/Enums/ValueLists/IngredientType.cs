﻿/// <summary>
/// The IngredientType
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum IngredientType
    {
        None,
        Object,
        Category,
        Property
    }
}
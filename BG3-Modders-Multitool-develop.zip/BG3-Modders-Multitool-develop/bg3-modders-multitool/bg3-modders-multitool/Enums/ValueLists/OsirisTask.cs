﻿/// <summary>
/// The Osiris Task
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum OsirisTask
    {
        None,
        Resurrect
    }
}
﻿/// <summary>
/// The ModifierType
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum ModifierType
    {
        Item,
        Charm,
        Boost,
        Skill,
        Crystal,
        Food
    }
}
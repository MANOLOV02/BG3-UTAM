﻿/// <summary>
/// The spell style group list.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum SpellStyleGroup
    {
        Intent,
        Class,
        Class_Intent
    }
}
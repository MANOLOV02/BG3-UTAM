﻿/// <summary>
/// The still animation prioties.
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum StillAnimPriority
    {
        Weakened,
        Feared,
        Blinded,
        Dazed,
        Mental,
        Sneaking,
        Sitting,
        Snared,
        KO_Fallen,
        Sleeping,
        KO,
        Downed,
        Shouting,
        Performing,
        Suffocating,
        Frightened,
    }
}
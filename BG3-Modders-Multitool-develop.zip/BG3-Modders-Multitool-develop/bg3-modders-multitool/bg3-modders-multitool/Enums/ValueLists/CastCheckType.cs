﻿/// <summary>
/// The CastCheckType
/// </summary>
namespace bg3_modders_multitool.Enums.ValueLists
{
    public enum CastCheckType
    {
        None,
        Distance,
        DamageType,
        TargetSurfaceType
    }
}
﻿/// <summary>
/// The translation model
/// </summary>
namespace bg3_modders_multitool.Models
{
    public class Translation
    {
        public string ContentUid { get; set; }
        public string Value { get; set; }
    }
}

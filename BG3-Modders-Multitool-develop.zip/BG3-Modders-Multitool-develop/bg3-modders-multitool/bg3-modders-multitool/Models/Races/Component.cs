﻿namespace bg3_modders_multitool.Models.Races
{
    public class Component
    {
        public string Type { get; set; }
        public string Guid { get; set; }
    }
}

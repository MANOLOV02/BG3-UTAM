﻿namespace bg3_modders_multitool.Views
{
    using System.Windows;

    /// <summary>
    /// Interaction logic for UnpackerProgress.xaml
    /// </summary>
    public partial class UnpackerProgress : Window
    {
        public UnpackerProgress()
        {
            InitializeComponent();
        }
    }
}

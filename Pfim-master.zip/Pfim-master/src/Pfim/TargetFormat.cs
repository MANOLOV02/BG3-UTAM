﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pfim
{
    public enum TargetFormat
    {
        Native
    }
}
